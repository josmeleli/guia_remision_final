<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class guia extends Model
{
    use HasFactory;
    protected $fillable = [
        'ruc',
        'razon_social',
        'direccion',
        'nro_guia',
        'nro_viaje',
        'pago',
        'campo',
        'transportista',
    ];
}
