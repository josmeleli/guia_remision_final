<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class transportista extends Model
{
    use HasFactory;

    protected $table = 'transportistas';
    protected $fillable = [
        'unidad_tecnica',
        'campo',
        'razon_social',
        'codigo',
        'nombre',
        'RUC',
    ];
}
