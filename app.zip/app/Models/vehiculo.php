<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class vehiculo extends Model
{
    use HasFactory;
    protected $fillable = [
        'placa',
        'codigo',
        'num_ejes',
        'id_transportista', // Esta es la clave foránea que relaciona los vehículos con los transportistas
    ];

        public function transportista()
    {
        return $this->belongsTo(Transportista::class, 'id_transportista');
    }

}
