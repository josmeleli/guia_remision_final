<?php

namespace App\Http\Controllers;

use App\Models\campo;
use Illuminate\Http\Request;
use App\Models\Guia;
use App\Models\Pago;
use App\Models\transportista;

class guiaController extends Controller
{
    public function index()
    {
        $guias = Guia::all();
        $pagos = Pago::all();
        $campos = campo::all();
        $transportistas = transportista::all();
        return view('guia_remision.index', compact('guias','pagos','campos','transportistas'));
    }
    public function store(Request $request)
    {
        // Validación de los datos del formulario
        $request->validate([
            'ruc' => 'required',
            'razon_social' => 'required',
            'direccion' => 'required',
            'nro_guia' => 'required',
            'nro_viaje' => 'required',
            'pago_id' => 'required|exists:pagos,id',
            'transportista_id' => 'required|exists:transportistas,id',
            'campo_id' => 'required|exists:campos,id',
        ]);

        // Crear una nueva instancia del modelo GuiaRemision con los datos del formulario
        $guiaRemision = new Guia();
        $guiaRemision->ruc = $request->ruc;
        $guiaRemision->razon_social = $request->razon_social;
        $guiaRemision->direccion = $request->direccion;
        $guiaRemision->nro_guia = $request->nro_guia;
        $guiaRemision->nro_viaje = $request->nro_viaje;
        $guiaRemision->pago_id = $request->pago_id;
        $guiaRemision->transportista_id = $request->transportista_id;
        $guiaRemision->campo_id = $request->campo_id;

        
        $guiaRemision->save();

        
        // Redireccionar de vuelta a la página anterior
    return back()->with('success', 'Guía de remisión creada exitosamente.');

    }

    public function edit($id)
    {
        
    }

    
    public function update(Request $request, $id)
    {
        $guia = Guia::findOrFail($id);
        $guia->ruc = $request->ruc;
        $guia->razon_social = $request->razon_social;
        $guia->direccion = $request->direccion;
        $guia->nro_guia = $request->nro_guia;
        $guia->nro_viaje = $request->nro_viaje;
        $guia->pago_id = $request->pago_id;
        $guia->campo_id = $request->campo_id;
        $guia->transportista_id = $request->transportista_id;

        // Guardar los cambios
        $guia->save();

        // Redirigir de vuelta al formulario de edición con un mensaje de éxito
        return redirect()->back()->with('success', 'Guía de remisión actualizada correctamente');
    }

    public function destroy($id)
    {
        try {
            $guia = Guia::findOrFail($id);
            $guia->delete();
            
            return redirect()->back()->with('success', 'Guía de remisión eliminada correctamente');
        } catch (\Exception $e) {
            // Manejo de errores si la guía no se encuentra o hay otros problemas
            return redirect()->back()->with('error', 'Error al eliminar la guía de remisión: ' . $e->getMessage());
        }
    }

    public function verificarRuc(Request $request)
    {
        // Obtiene el RUC del parámetro de la solicitud
        $ruc = $request->get('ruc');

        // Busca un transportista con el RUC dado en la base de datos
        $transportista = Transportista::where('RUC', $ruc)->first();

        // Verifica si se encontró un transportista con el RUC dado
        if ($transportista) {
            // Si se encuentra, devuelve una respuesta JSON con 'registrado' como verdadero
            return response()->json(['registrado' => true]);
        } else {
            // Si no se encuentra, devuelve una respuesta JSON con 'registrado' como falso
            return response()->json(['registrado' => false]);
        }
    }
    

}
