<?php

namespace App\Http\Controllers;

use App\Models\agricultor;
use Illuminate\Http\Request;
use App\Models\vehiculo;
use App\Models\Transportista;
use App\Models\chofer;
use App\Models\Carga;
use App\Models\Pago;
use App\Models\campo;
use App\Models\Guia;
use App\Models\User;

class vehiculoController extends Controller
{
    public function index()
    {
        $guias = Guia::all();
        $choferes = Chofer::all();
        $vehiculos = vehiculo::all();
        $cargas = Carga::all();
        $pagos = Pago::all();
        $agricultores = Agricultor::all();
        $campos = campo::all();
        $transportistas = transportista::all();
        $user = User::first();
        $message = '¡Hola! ' . $user->name;
        return view('vehiculos.index', compact('guias','pagos','campos','transportistas','agricultores','cargas','choferes','vehiculos','message'));
    }

    public function mostrarMenu()
    {
        $transportistas = Transportista::all();
        $agricultores = Agricultor::all();
        $cargas = Carga::all();
        $vehiculos = vehiculo::all();
        $pagos = Pago::all();
        $campos = campo::all();
        $conductores = chofer::all(); // Obtener todos los conductores

        $user = User::first();
        $message = '¡Hola! ' . $user->name;
        
        
        return view('menu', compact('transportistas', 'conductores', 'agricultores', 'cargas', 'vehiculos', 'pagos', 'campos', 'message'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'placa' => 'required',
            'codigo' => 'required',
            'num_ejes' => 'required',
            'id_transportista' => 'required'

        ]);

        $datos = new vehiculo();

        $datos-> placa = $request-> placa;
        $datos-> codigo = $request-> codigo;
        $datos-> num_ejes = $request-> num_ejes;
        $datos->id_transportista = $request->id_transportista;

        $datos->save();

        return redirect()->route('mostrar.menu')->with('success', 'Vehiculo guardado correctamente');
        
    }

    public function update(Request $request, $id)
    {
        $vehiculo = vehiculo::findOrFail($id);
        $vehiculo->placa = $request->placa;
        $vehiculo->codigo = $request->codigo;
        $vehiculo->num_ejes = $request->num_ejes;
        $vehiculo->id_transportista = $request->id_transportista;
       
       

        // Guardar los cambios
        $vehiculo->save();

        // Redirigir de vuelta al formulario de edición con un mensaje de éxito
        return redirect()->back()->with('success', 'Vehiculo actualizado correctamente');
    }

    public function destroy($id)
    {
        try {
            $vehiculo = vehiculo::findOrFail($id);
            $vehiculo->delete();
            
            return redirect()->back()->with('success', 'Vehiculo eliminado correctamente');
        } catch (\Exception $e) {
            // Manejo de errores si la guía no se encuentra o hay otros problemas
            return redirect()->back()->with('error', 'Error al eliminar Vehiculo: ' . $e->getMessage());
        }
    }


        
    
}
