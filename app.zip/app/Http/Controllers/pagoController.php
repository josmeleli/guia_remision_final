<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Pago;
use App\Models\Guia;
use App\Models\campo;
use App\Models\transportista;
use App\Models\vehiculo;

class pagoController extends Controller
{
    public function index()
    {
        $guias = Guia::all();
        $pagos = Pago::all();
        $campos = campo::all();
        $transportistas = transportista::all();
        return view('pago.index', compact('guias','pagos','campos','transportistas'));
    }
    public function store(Request $request)
{
    // Validar los datos del formulario
    $request->validate([
        
        'precio_unitario' => 'required|numeric',
       
        'adelanto' => 'required|numeric',
        
    ]);

    // Crear un nuevo pago
    Pago::create([
        
        'precio_unitario' => $request->precio_unitario,
       
        'adelanto' => $request->adelanto,
        
    ]);

    // Redireccionar a una ruta después de guardar el pago (opcional)
    return redirect()->route('mostrar.menu')->with('success', '¡El pago ha sido registrado correctamente!');
}
public function edit($id)
{
    
}


public function update(Request $request, $id)
{
    $pago = Pago::findOrFail($id);
    $pago->precio_unitario = $request->precio_unitario;
    $pago->adelanto = $request->adelanto;
   

    // Guardar los cambios
    $pago->save();

    // Redirigir de vuelta al formulario de edición con un mensaje de éxito
    return redirect()->back()->with('success', 'Guía de remisión actualizada correctamente');
}
    public function destroy($id)
    {
        try {
            $guia = Pago::findOrFail($id);
            $guia->delete();
            
            return redirect()->back()->with('success', 'Pago eliminado correctamente');
        } catch (\Exception $e) {
            // Manejo de errores si la guía no se encuentra o hay otros problemas
            return redirect()->back()->with('error', 'Error al pago: ' . $e->getMessage());
        }
    }

}
