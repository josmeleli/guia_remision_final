<!-- Aquí puedes agregar tu formulario, tabla u otro contenido -->



<?php $__env->startSection('content'); ?>




<div class="container">
    <div class="row">
        <div class="col">
            <div class="cinta active" id="parte1">CAMPO - CONDUCTOR</div>
        </div>
        <div class="col">
            <div class="cinta" id="parte2">CARGA - AGRICULTOR</div>
        </div>
        
    </div>

    <div class="formulario-container active" id="formularios1">

    </div>
    <div class="formulario-container active" id="formularios1">
        
    </div>
    <div class="mas-partes" style="margin-bottom:20PX ">
        <i class="fas fa-plus"></i> Más Partes
    </div>

</div>
<div class="container">
    <h1>Filtrar Datos Avanzados</h1>
    <form action="<?php echo e(route('filtro.avanzado')); ?>" method="GET" id="filtro-form">
        <div class="row">
            <div class="col-md-4">
                <div class="form-group">
                    <label for="ruc">RUC de la Guía:</label>
                    <input type="text" name="ruc" class="form-control" placeholder="Ingrese RUC">
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="razon_social">Razón Social:</label>
                    <input type="text" name="razon_social" class="form-control" placeholder="Ingrese Razón Social">
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="direccion">Dirección:</label>
                    <input type="text" name="direccion" class="form-control" placeholder="Ingrese Dirección">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="form-group">
                    <label for="nro_guia">Número de Guía:</label>
                    <input type="text" name="nro_guia" class="form-control" placeholder="Ingrese Número de Guía">
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="nro_viaje">Número de Viaje:</label>
                    <input type="text" name="nro_viaje" class="form-control" placeholder="Ingrese Número de Viaje">
                </div>
            </div>
            <!-- Agrega más campos de filtro según sea necesario -->
        </div>
        <div class="row">
            <div class="col-md-12">
                <button type="submit" class="btn btn-primary">Filtrar</button>
                <button type="button" class="btn btn-secondary" id="limpiar-btn">Limpiar Campos</button>
            </div>
        </div>
    </form>
</div>

    






<div class="card">
    <div class="card-header">
        <h3 class="card-title">Tabla de Filtros Avanzados</h3>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered table-hover" id="guia-table" >
                <thead>
                    <tr>
                        <th>N°</th>
                        <th>RUC</th>
                        <th>Razón Social</th>
                        <th>Dirección</th>
                        <th>Número de Guía</th>
                        <th>Número de Viaje</th>
                        <th>Adelanto</th>
                        <th>Precio Unitario</th>
                        <th>Carga Bruta</th>
                        <th>Carga Neta</th>
                        <th>Material Extraño</th>
                        <th>Km de Origen</th>
                        <th>Km de Destino</th> 
                        <th>Fecha de Carga</th> 
                        <th>Fecha de Descarga</th> 
                        <th>Acopiadora</th>
                        <th>Ubigeo</th>
                        <th>Zona</th>
                        <th>Ingenio</th>
                        <th>Unidad Tecnica</th>
                        <th>Campo</th>
                        <th>Nombre Transportista</th>
                        <th>Datos del Conductor</th>
                        <th>DNI Conductor</th>
                        <th>Placa</th>
                        <th>Codigo Vehiculo</th>
                        <th>Numero de Ejes</th>
                        <th>Nombre Agricultor</th>
                        <th>Apellidos Agricultor</th>
                        <th>DNI Agricultor</th>

                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($dato->ruc); ?></td>
                        <td><?php echo e($dato->razon_social); ?></td>
                        <td><?php echo e($dato->direccion); ?></td>
                        <td><?php echo e($dato->nro_guia); ?></td>
                        <td><?php echo e($dato->nro_viaje); ?></td>
                        <td><?php echo e($dato->adelanto); ?></td>
                        <td><?php echo e($dato->precio_unitario); ?></td>
                        <td><?php echo e($dato->total_carga_bruta); ?></td>
                        <td><?php echo e($dato->total_carga_neta); ?></td>
                        <td><?php echo e($dato->total_material_extrano); ?></td>
                        <td><?php echo e($dato->km_origen); ?></td>
                        <td><?php echo e($dato->km_de_destino); ?></td>
                        <td><?php echo e($dato->fecha_carga); ?></td>
                        <td><?php echo e($dato->fecha_de_descarga); ?></td>
                        <td><?php echo e($dato->acopiadora); ?></td>
                        <td><?php echo e($dato->ubigeo); ?></td>
                        <td><?php echo e($dato->zona); ?></td>
                        <td><?php echo e($dato->ingenio); ?></td>
                        <td><?php echo e($dato->unidad_tecnica); ?></td>
                        <td><?php echo e($dato->campo); ?></td>
                        <td><?php echo e($dato->nombre_transportista); ?></td>
                        <td><?php echo e($dato->datos_conductor); ?></td>
                        <td><?php echo e($dato->dni_conductor); ?></td>
                        <td><?php echo e($dato->placa); ?></td>
                        <td><?php echo e($dato->codigo_vehiculo); ?></td>
                        <td><?php echo e($dato->num_ejes); ?></td>
                        <td><?php echo e($dato->nombres_agricultor); ?></td>
                        <td><?php echo e($dato->apellidos_agricultor); ?></td>
                        <td><?php echo e($dato->dni_agricultor); ?></td>
                        
                    </tr>
                    <?php if($loop->iteration % 10 == 0): ?>
                </tbody>
            </table>
        </div>
        <div class="table-responsive">
            <table class="table table-bordered table-hover" id="guia-table">
                <thead>
                    <tr>
                        <th>N°</th>
                        <th>RUC</th>
                        <th>Razón Social</th>
                        <th>Dirección</th>
                        <th>Número de Guía</th>
                        <th>Número de Viaje</th>
                        <th>Adelanto</th>
                        <th>Precio Unitario</th>
                        <th>Carga Bruta</th>
                        <th>Carga Neta</th>
                        <th>Material Extraño</th>
                        <th>Km de Origen</th>
                        <th>Km de Destino</th> 
                        <th>Fecha de Carga</th> 
                        <th>Fecha de Descarga</th> 
                        <th>Acopiadora</th>
                        <th>Ubigeo</th>
                        <th>Zona</th>
                        <th>Ingenio</th>
                        <th>Unidad Tecnica</th>
                        <th>Campo</th>
                        <th>Nombre Transportista</th>
                        <th>Datos del Conductor</th>
                        <th>DNI Conductor</th>
                        <th>Placa</th>
                        <th>Codigo Vehiculo</th>
                        <th>Numero de Ejes</th>
                        <th>Nombre Agricultor</th>
                        <th>Apellidos Agricultor</th>
                        <th>DNI Agricultor</th>
                    </tr>
                </thead>
                <tbody>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


<script>
    // Espera a que el documento esté completamente cargado

    // Espera a que el documento esté completamente cargado
    $(document).ready(function() {
        // Función para filtrar y actualizar la tabla
        function updateTable() {
            // Obtener los valores de los filtros
            var rucValue = $("#ruc-filter").val().toUpperCase();
            var razonSocialValue = $("#razon_social-filter").val().toUpperCase();
            var direccionValue = $("#direccion-filter").val().toUpperCase();
            var nroGuiaValue = $("#nro_guia-filter").val().toUpperCase();
            var nroViajeValue = $("#nro_viaje-filter").val().toUpperCase();

            // Iterar sobre las filas y mostrar/ocultar según los filtros
            $("#guia-table tbody tr").each(function() {
                var rowData = $(this).find("td");
                var ruc = rowData.eq(1).text().toUpperCase();
                var razonSocial = rowData.eq(2).text().toUpperCase();
                var direccion = rowData.eq(3).text().toUpperCase();
                var nroGuia = rowData.eq(4).text().toUpperCase();
                var nroViaje = rowData.eq(5).text().toUpperCase();

                // Comprobar si la fila debe mostrarse
                if (ruc.indexOf(rucValue) !== -1 &&
                    razonSocial.indexOf(razonSocialValue) !== -1 &&
                    direccion.indexOf(direccionValue) !== -1 &&
                    nroGuia.indexOf(nroGuiaValue) !== -1 &&
                    nroViaje.indexOf(nroViajeValue) !== -1) {
                    $(this).show();
                } else {
                    $(this).hide();
                }
            });
        }

        // Agregar eventos de cambio para cada filtro
        $("#ruc-filter, #razon_social-filter, #direccion-filter, #nro_guia-filter, #nro_viaje-filter").on("keyup change", updateTable);

        // Llamar a la función updateTable() al inicio para aplicar los filtros iniciales
        updateTable();
    });
</script>

<script>
    // Script para limpiar los campos del formulario
    document.addEventListener('DOMContentLoaded', function() {
        document.getElementById('limpiar-btn').addEventListener('click', function() {
            document.getElementById('filtro-form').reset(); // Resetea el formulario
        });
    });
</script>
<script>
    $(document).ready(function() {
        // Función para enviar la solicitud AJAX al servidor
        function filtrarDatos() {
            // Obtener los valores de los campos de filtro
            var ruc = $('#ruc-filter').val();
            var razonSocial = $('#razon_social-filter').val();
            var direccion = $('#direccion-filter').val();
            var nroGuia = $('#nro_guia-filter').val();
            var nroViaje = $('#nro_viaje-filter').val();
            
            // Realizar la solicitud AJAX
            $.ajax({
                type: 'GET',
                url: '<?php echo e(route("filtros.avanzados")); ?>', // Reemplaza 'ruta.filtrar' con la ruta adecuada en tu aplicación
                data: {
                    ruc: ruc,
                    razon_social: razonSocial,
                    direccion: direccion,
                    nro_guia: nroGuia,
                    nro_viaje: nroViaje
                },
                success: function(response) {
                    // Actualizar el contenido de la tabla con los resultados filtrados
                    $('#tabla-resultados').html(response);
                },
                error: function(xhr, status, error) {
                    console.error(error);
                }
            });
        }

        // Asignar la función filtrarDatos al evento de cambio en los campos de filtro
        $('#ruc-filter, #razon_social-filter, #direccion-filter, #nro_guia-filter, #nro_viaje-filter').change(function() {
            filtrarDatos();
        });

        // Función para limpiar los campos de filtro y mostrar todos los datos
        $('#limpiar-filtros').click(function() {
            $('#ruc-filter, #razon_social-filter, #direccion-filter, #nro_guia-filter, #nro_viaje-filter').val('');
            filtrarDatos(); // Volver a mostrar todos los datos
        });
    });
</script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>



<style>
    .parte-selector-container {
        display: flex;
        justify-content: space-around;
        background-color: #007bff;
        color: #fff;
        padding: 10px 0;
        cursor: pointer;
        border-radius: 50px;
        margin-top: 20px;
    }
    .parte-selector.active {
        background-color: #28a745;
    }
    .formulario-container {
        display: flex;
        justify-content: space-between;
        margin-top: 20px;
        display: none;
    }
    .formulario-container.active {
        display: flex;
    }
    .form-group {
        flex: 1;
        margin-right: 10px;
    }
    .cinta {
        border-top-left-radius: 50px;
        border-top-right-radius: 50px;
        background-color: #1B62FF;
        color: #fff;
        padding: 10px 0;
        text-align: center;
        cursor: pointer;
    }
    .cinta.active {
        background-color: #0003A3;
    }
    .mas-partes {
        display: flex;
        justify-content: center;
        align-items: center;
        background-color: #007bff;
        color: #fff;
        border-bottom-left-radius: 50px;
        border-bottom-right-radius: 50px;
        cursor: pointer;
        margin-top: 20px;
    }
    .mas-partes:hover {
        background-color: #1B62FF;
    }
    .formularios {
    display: none; /* Oculta los formularios adicionales inicialmente */
}
@end
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\guiaAdminRemision-version3\resources\views/filtrosAvanzados.blade.php ENDPATH**/ ?>