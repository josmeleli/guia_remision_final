<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('guias', function (Blueprint $table) {
            $table->id();
            $table->string('ruc');
            $table->string('razon_social');
            $table->string('direccion');
            $table->string('nro_guia');
            $table->string('nro_viaje');
            $table->foreignId('pago_id')->constrained('pagos');
            $table->foreignId('campo_id')->constrained('campos');
            $table->foreignId('transportista_id')->constrained('transportistas');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('guias');
    }
};
