@extends('layouts.sidebar')

@extends('layouts.header')

@section('content')

<div class="container">
    <div class="row">
        <div>
            <h3>Guias de Remision</h3>
        </div>
        <div class="mr-3"></div>
       

        

    </div>

   
        
    <div id="tables-wrapper" class="tables-wrapper">

                @foreach($guias->chunk(4) as $chunk)
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>RUC</th>
                            <th>Razón Social</th>
                            <th>Dirección</th>
                            <th>N° Guía de Remisión</th>
                            <th>N° de Viaje</th>
                            <th>Pago</th>
                            <th>Campo</th>
                            <th>Transportista</th>
                            <th>Acciones</th> <!-- Nueva columna para las acciones CRUD -->
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($chunk as $guia)
                            <tr>
                                <td>{{ $guia->id }}</td>
                                <td>{{ $guia->ruc }}</td>
                                <td>{{ $guia->razon_social }}</td>
                                <td>{{ $guia->direccion }}</td>
                                <td>{{ $guia->nro_guia }}</td>
                                <td>{{ $guia->nro_viaje }}</td>
                                <td>{{ $guia->pago_id }}</td>
                                <td>{{ $guia->campo_id }}</td>
                                <td>{{ $guia->transportista_id }}</td>
                                <td>
                                    
                                    <button type="button" class="btn btn-primary btn-sm mb-1" data-toggle="modal" data-target="#editModal{{ $guia->id }}">
                                        <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-edit" width="20" height="20" viewBox="0 0 24 24" stroke-width="1.5" stroke="#2c3e50" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                            <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                                            <path d="M7 7h-1a2 2 0 0 0 -2 2v9a2 2 0 0 0 2 2h9a2 2 0 0 0 2 -2v-1" />
                                            <path d="M20.385 6.585a2.1 2.1 0 0 0 -2.97 -2.97l-8.415 8.385v3h3l8.385 -8.415z" />
                                            <path d="M16 5l3 3" />
                                          </svg>
                                    </button>
        
                                    <!-- Modal para editar la guía de remisión -->
                                    <div class="modal fade" id="editModal{{ $guia->id }}" tabindex="-1" aria-labelledby="editModalLabel{{ $guia->id }}" aria-hidden="true">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content">
                                                <div class="modal-header bg-primary">
                                                    <h5 class="modal-title" id="editModalLabel{{ $guia->id }}">Editar Guía de Remisión</h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <!-- Formulario para editar la guía de remisión -->
                                                    <form id="editForm{{ $guia->id }}" action="{{ route('guias.update', $guia->id) }}" method="POST">
                                                        @csrf
                                                        @method('PUT')
                                                        <!-- Campos para editar -->
                                                        <div class="form-group row">
                                                            <div class="col-md-6 ">
                                                                <label for="ruc">RUC</label>
                                                                <input type="text" class="form-control" id="ruc" name="ruc" value="{{ $guia->ruc }}" required>
        
                                                            </div>
                                                            <div class="col-md-6">
                                                                <label for="razon_social">Razon Social: </label>
                                                                <input type="text" class="form-control" id="razon_social" name="razon_social" value="{{ $guia->razon_social }}" required>
        
                                                            </div>
                                                           
                                                        </div>
                                                        
                                                        <div class="form-group row">
                                                            <div class="col-md-6">
                                                                <label for="direccion">Dirección: </label>
                                                                <input type="text" class="form-control" id="direccion" name="direccion" value="{{ $guia->direccion }}" required>
        
                                                            </div>
                                                            <div class="col-md-6">
                                                                <label for="nro_guia">N° de Guia de Remisión</label>
                                                                <input type="text" class="form-control" id="nro_guia" name="nro_guia" value="{{ $guia->nro_guia }}" required>
        
                                                            </div>
                                                            
                                                        </div>
                                                        
                                                        <div class="form-group row">
                                                            <div class="col-md-6">
                                                                <label for="nro_viaje">N° de Viaje</label>
                                                                <input type="text" class="form-control" id="nro_viaje" name="nro_viaje" value="{{ $guia->nro_viaje }}" required>
        
                                                            </div>
                                                            <div class="col-md-6">
                                                                <label for="pago_id">Pago: </label>
                                                                <select class="form-control" id="pago_id" name="pago_id" required>
                                                                    <option value="" selected disabled >{{$guia->pago_id}}</option>
                                                                    @foreach($pagos as $pago)
                                                                        <option value="{{ $pago->id }}" {{ $pago->pago_id == $pago->id ? 'selected' : '' }}>{{ $pago->adelanto }}</option>
                                                                    @endforeach
                                                                </select>
        
                                                            </div>
                                                            
                                                        </div>
                                                        
                                                        <div class="form-group row">
                                                            <div class="col-md-6">
                                                                <label for="transportista_id">Transportista: </label>
                                                                <select class="form-control" id="transportista_id" name="transportista_id" required>
                                                                    <option value="" selected disabled >{{$guia->transportista_id}}</option>
                                                                    @foreach($transportistas as $transportista)
                                                                        <option value="{{ $transportista->id }}" {{ $transportista->transportista_id == $transportista->id ? 'selected' : '' }}>{{ $transportista->razon_social }}</option>
                                                                    @endforeach
                                                                </select>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <label for="campo_id">Campo:</label>
                                                                <select class="form-control" id="campo_id" name="campo_id" required>
                                                                    <option value="" selected disabled >{{$guia->campo_id}} </option>
                                                                    @foreach($campos as $campo)
                                                                        <option value="{{ $campo->id }}" {{ $guia->campo_id == $campo->id ? 'selected' : '' }}>{{ $campo->zona }}</option>
                                                                    @endforeach
                                                                </select>
        
                                                            </div>
                                                           
                                                        </div>
                                            
                                                        <!-- Agrega aquí más campos para editar -->
                                                        <button type="submit" class="btn btn-primary">Guardar Cambios</button>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
        
        
                                    <form action="{{ route('guias.destroy', $guia->id) }}" method="POST" style="display: inline-block;">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-danger btn-sm">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-trash-x-filled" width="20" height="20" viewBox="0 0 24 24" stroke-width="1.5" stroke="#2c3e50" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                                <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                                                <path d="M20 6a1 1 0 0 1 .117 1.993l-.117 .007h-.081l-.919 11a3 3 0 0 1 -2.824 2.995l-.176 .005h-8c-1.598 0 -2.904 -1.249 -2.992 -2.75l-.005 -.167l-.923 -11.083h-.08a1 1 0 0 1 -.117 -1.993l.117 -.007h16zm-9.489 5.14a1 1 0 0 0 -1.218 1.567l1.292 1.293l-1.292 1.293l-.083 .094a1 1 0 0 0 1.497 1.32l1.293 -1.292l1.293 1.292l.094 .083a1 1 0 0 0 1.32 -1.497l-1.292 -1.293l1.292 -1.293l.083 -.094a1 1 0 0 0 -1.497 -1.32l-1.293 1.292l-1.293 -1.292l-.094 -.083z" stroke-width="0" fill="currentColor" />
                                                <path d="M14 2a2 2 0 0 1 2 2a1 1 0 0 1 -1.993 .117l-.007 -.117h-4l-.007 .117a1 1 0 0 1 -1.993 -.117a2 2 0 0 1 1.85 -1.995l.15 -.005h4z" stroke-width="0" fill="currentColor" />
                                              </svg>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
                @endforeach
           
            
        
     
    </div>

    <div class="navigation">
        <button id="prev-btn" onclick="prevTable()">
            <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-arrow-big-right-filled" width="16" height="16" viewBox="0 0 24 24" stroke-width="1.5" stroke="#ffffff" fill="none" stroke-linecap="round" stroke-linejoin="round">
                <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                <path d="M12.089 3.634a2 2 0 0 0 -1.089 1.78l-.001 2.586h-6.999a2 2 0 0 0 -2 2v4l.005 .15a2 2 0 0 0 1.995 1.85l6.999 -.001l.001 2.587a2 2 0 0 0 3.414 1.414l6.586 -6.586a2 2 0 0 0 0 -2.828l-6.586 -6.586a2 2 0 0 0 -2.18 -.434l-.145 .068z" stroke-width="0" fill="currentColor" />
              </svg>
        </button>
      <div id="table-numbers" class="table-numbers"></div>
        <button id="next-btn" onclick="prevTable()">
            <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-arrow-big-right-filled" width="16" height="16" viewBox="0 0 24 24" stroke-width="1.5" stroke="#ffffff" fill="none" stroke-linecap="round" stroke-linejoin="round">
                <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
                <path d="M12.089 3.634a2 2 0 0 0 -1.089 1.78l-.001 2.586h-6.999a2 2 0 0 0 -2 2v4l.005 .15a2 2 0 0 0 1.995 1.85l6.999 -.001l.001 2.587a2 2 0 0 0 3.414 1.414l6.586 -6.586a2 2 0 0 0 0 -2.828l-6.586 -6.586a2 2 0 0 0 -2.18 -.434l-.145 .068z" stroke-width="0" fill="currentColor" />
              </svg>
        </button>
    </div>

    
      
      

</div>

<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
    Mas Opciones
</button>

<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Registrar Guia de Remision</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
            <div class="table-responsive" style="max-height: 300px; overflow-y: auto;">
                <form action="{{ route('guia_remision.store') }}" method="POST">
                    @csrf
                
                    <div class="d-flex mb-3">
                        <div class="input-group">
                            <input type="text" class="form-control pr-2" id="rucInput" name ="ruc" placeholder="RUC">
                            <div class="input-group-append">
                                <button type="button" id="consultarBtn" data-token="{{ env('RUC_API_TOKEN') }}" style="background-color:#001F4B; color:white; border: solid 2px  #001F4B;border-radius:0 6px 6px 0 "><i class="fas fa-search"></i> Consultar</button>
                            </div>
                        </div>
                        <div class="mr-4"></div>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-user"></i></span>
                            </div>
                            <input type="text" class="form-control" id="razonSocialInput" name="razon_social" placeholder="Razon Social">
                        </div>
                    </div>
        
                        <div class="input-group mb-3">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-map-marker-alt"></i></span>
                            </div>
                            <input type="text" class="form-control" id="direccionInput" name="direccion" placeholder="Direccion">
                        </div>
                
                    <div class="d-flex mb-3">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-file-alt"></i></span>
                            </div>
                            <input type="text" class="form-control" id="nro_guia" name="nro_guia" placeholder="N° Guia de Remision">
                        </div>
                        <div class="mr-4"></div>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-truck"></i></span>
                            </div>
                            <input type="text" class="form-control" id="nro_viaje" name="nro_viaje" placeholder="N° de Viaje">
                        </div>
                    </div>
                    <div class="d-flex mb-3">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-coins"></i></span>
                            </div>
                            <input class="form-control" list="pagoList" id="pago" name="pago_id" placeholder="PAGO">
                            <datalist id="pagoList">
                                @foreach($pagos->reverse() as $pago)
                                    <option value="{{ $pago->id }}">{{ $pago->adelanto }}</option>
                                @endforeach
                            </datalist>
                        </div>
                        <div class="mr-4"></div>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-tree"></i></span>
                            </div>
                            <input class="form-control" list="campoList" id="campo" name="campo_id" placeholder="CAMPO">
                            <datalist id="campoList">
                                @foreach($campos->reverse() as $campos)
                                    <option value="{{ $campos->id }}">{{ $campos->zona }}</option>
                                @endforeach
                            </datalist>
                            
                        </div>
                        <div class="mr-4"></div>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-building"></i></span>
                            </div>
                            <input class="form-control" list="transportistaList" id="transportista" name="transportista_id" placeholder="TRANSPORTISTA">
                            <datalist id="transportistaList">
                                @foreach($transportistas->reverse() as $transportista)
                                    <option value="{{ $transportista->id }}">{{ $transportista->razon_social }}</option>
                                @endforeach
                            </datalist>
                        </div>
                    </div>
                    
                
                    <div class="text-center mb-0" >
                        <button type="submit"  class="btn btn-primary"> GUARDAR  <i class="fas fa-save"></i></button>
                        <button type="reset" class="btn btn-secondary " id="limpiar-btn" >
                            <i class="fas fa-broom"></i> Limpiar
                        </button>
                    </div>
                </form>

            </div>

       
        
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
          
        </div>
      </div>
    </div>
</div>

<link rel="stylesheet" href="css/mult.css">


<script src="js/prevNex.js"></script>
<script src="{{ asset('js/api.js') }}"></script>






@endSection


@section('css')
<link rel="stylesheet" href="{{ asset('css/styleTables.css') }}">
@endSection
